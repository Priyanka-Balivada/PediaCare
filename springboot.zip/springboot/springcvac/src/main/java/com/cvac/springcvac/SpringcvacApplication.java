package com.cvac.springcvac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcvacApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcvacApplication.class, args);
	}

}
